package xlsys.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import xlsys.io.util.IOUtil;

/**
 * 加解密工具类
 * 已废弃，使用EDCoder来替代
 * @author Lewis
 *
 */
@Deprecated
public class EDCode
{
	public final static String SECRET_KEY = "secretKey.sk";
	private static EDCode edCode;
	private BASE64Encoder base64encoder;
	private BASE64Decoder base64decoder;
	
	private SecretKey secretKey;
	private Cipher cipher;
	
	/**
	 * 使用输入流构造一个EDCode
	 * @param in
	 */
	public EDCode(InputStream in)
	{
		try
		{
			init(in);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 使用文件路径构造一个EDCode
	 * @param filePath
	 */
	public EDCode(String filePath)
	{
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(filePath);
			init(fis);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			IOUtil.close(fis);
		}
	}
	
	private void init(InputStream is) throws Exception
	{
		secretKey = getSecretKey(is);
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		String Algorithm = "DES";
		cipher = Cipher.getInstance(Algorithm);
		base64encoder = new BASE64Encoder();
		base64decoder = new BASE64Decoder();
	}
	
	/**
	 * 获取默认的EDCode实例
	 * @return
	 */
	public static EDCode getDefaultInstance()
	{
		if(edCode==null)
		{
			String keyFile = "/" + StringUtil.transJavaPackToPath(EDCode.class.getPackage().getName()).replaceAll("\\\\", "/") + "/"+SECRET_KEY;
			InputStream is = EDCode.class.getResourceAsStream(keyFile);
			edCode = new EDCode(is);
			IOUtil.close(is);
		}
		return edCode;
	}

	/**
	 * 生成密钥文件到指定路径中
	 * @param filePath 要存放密钥文件的路径
	 * @throws Exception
	 */
	public static void generateKey(String filePath) throws Exception
	{
		Security.addProvider(new com.sun.crypto.provider.SunJCE());
		String Algorithm = "DES"; // 定义 加密算法,可用 DES,DESede,Blowfish
		KeyGenerator keygen = KeyGenerator.getInstance(Algorithm);
		SecretKey deskey = keygen.generateKey();
		FileOutputStream fos = new FileOutputStream(filePath);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(deskey);
		oos.close();
	}
	
	/**
	 * 从读入流中获取密钥
	 * @param is
	 * @return
	 * @throws Exception
	 */
	public static SecretKey getSecretKey(InputStream is) throws Exception
	{
		ObjectInputStream ois = new ObjectInputStream(is);
		SecretKey deskey = (SecretKey) ois.readObject();
		return deskey;
	}
	
	/**
	 * 加密数据
	 * @param srcBytes 原始的字节数组
	 * @return 加密后的字符串，失败返回null
	 */
	public String encrypt(byte[] srcBytes)
	{
		String str = null;
		try
		{
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			byte[] cipherByte = cipher.doFinal(srcBytes);
			str = base64encoder.encode(cipherByte);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return str;
	}
	
	/**
	 * 解密数据
	 * @param encryptStr 密文
	 * @return 解密后的字节数组
	 */
	public byte[] decrypt(String encryptStr)
	{
		byte[] srcBytes = null;
		try
		{
			byte[] encodeByte = base64decoder.decodeBuffer(encryptStr);
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			srcBytes = cipher.doFinal(encodeByte);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return srcBytes;
	}
	
	/**
	 * 字节数组转unicode字符串
	 * @param b
	 * @return
	 */
	public String byteToUnicode(byte[] b)
	{
		String str = "";
		for(int i=0;i<b.length;i++)
		{
			str += b[i];
			if(i!=b.length-1)
			{
				str += ",";
			}
		}
		return str;
	}
	
	/**
	 * unicode字符串转字节数组
	 * @param unicodeStr
	 * @return
	 */
	public byte[] UnicodeToByte(String unicodeStr)
	{
		String[] unicode = unicodeStr.split(",");
		byte[] b = new byte[unicode.length];
		for(int i=0;i<b.length;i++)
		{
			b[i] = Integer.valueOf(unicode[i]).byteValue();
		}
		return b;
	}
}
